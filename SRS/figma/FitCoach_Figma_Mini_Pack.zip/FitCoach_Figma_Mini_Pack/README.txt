FitCoach – Figma Import Mini Pack
Generated: 2025-09-28T17:05:17.771606Z

Folders:
- user/*.svg    (mobile frames for user app, 360x800)
- coach/*.svg   (mobile frames for coach app, 360x800)
- admin/*.svg   (web frames for admin app, 1440x1024)
- design-tokens.json (Figma Tokens / Tokens Studio JSON)

How to import into Figma:
1) Unzip this archive.
2) Drag & drop the SVGs into your Figma canvas (they import as frames).
3) Install "Tokens Studio for Figma" plugin.
4) Import design-tokens.json to create color/text/spacing tokens.
5) Select frames and apply styles to backgrounds and text.

To match your reference theme:
- Replace the hex codes in design-tokens.json with the exact values from your Figma Variables or Styles.
- Or re-run this script with --primary/--bg/--surface/--text etc. to regenerate with your palette.
