FitCoach – Figma Full Import Pack
Generated: 2025-09-28T17:15:32.968490Z

This pack contains:
- user/*.svg (mobile frames, 360x800)
- coach/*.svg (mobile frames, 360x800)
- admin/*.svg (web frames, 1440x1024)
- design-tokens.json (Tokens Studio format)

How to use:
1) Unzip.
2) Drag the SVGs into Figma (they import as frames).
3) Open Tokens Studio → Import design-tokens.json → Apply styles to the frames.
4) If you provided --icons (your SVGs), header icons are embedded; otherwise placeholders are used.
