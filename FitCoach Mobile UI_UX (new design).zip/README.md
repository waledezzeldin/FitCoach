
  # FitCoach Mobile UI/UX (new design)

  This is a code bundle for FitCoach Mobile UI/UX (new design). The original project is available at https://www.figma.com/design/1DUe9hVY0Ji3XeTPvOppSH/FitCoach-Mobile-UI-UX--new-design-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  