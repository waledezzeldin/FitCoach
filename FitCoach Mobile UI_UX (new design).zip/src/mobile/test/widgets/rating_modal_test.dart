import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/widgets/rating_modal.dart';

void main() {
  group('RatingModal Widget Tests', () {
    testWidgets('renders with title and description', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate Your Session',
              description: 'How was your workout?',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      expect(find.text('Rate Your Session'), findsOneWidget);
      expect(find.text('How was your workout?'), findsOneWidget);
    });

    testWidgets('shows 5 stars', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      expect(find.byIcon(Icons.star_outline), findsNWidgets(5));
    });

    testWidgets('tapping star updates selection', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      // Tap third star
      await tester.tap(find.byIcon(Icons.star_outline).at(2));
      await tester.pumpAndSettle();

      // Should show 3 filled stars
      expect(find.byIcon(Icons.star), findsNWidgets(3));
      expect(find.byIcon(Icons.star_outline), findsNWidgets(2));
    });

    testWidgets('shows rating labels', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      // Tap different stars and check labels
      await tester.tap(find.byIcon(Icons.star_outline).first);
      await tester.pumpAndSettle();
      expect(find.text('Poor'), findsOneWidget);

      await tester.tap(find.byIcon(Icons.star_outline).at(2));
      await tester.pumpAndSettle();
      expect(find.text('Good'), findsOneWidget);

      await tester.tap(find.byIcon(Icons.star_outline).last);
      await tester.pumpAndSettle();
      expect(find.text('Excellent'), findsOneWidget);
    });

    testWidgets('shows feedback text field', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              showFeedbackField: true,
            ),
          ),
        ),
      );

      expect(find.byType(TextField), findsOneWidget);
      expect(find.text('Additional feedback (optional)'), findsOneWidget);
    });

    testWidgets('hides feedback field when disabled', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              showFeedbackField: false,
            ),
          ),
        ),
      );

      expect(find.byType(TextField), findsNothing);
    });

    testWidgets('submit button calls callback with rating', (WidgetTester tester) async {
      int? submittedRating;
      String? submittedFeedback;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {
                submittedRating = rating;
                submittedFeedback = feedback;
              },
            ),
          ),
        ),
      );

      // Select 4 stars
      await tester.tap(find.byIcon(Icons.star_outline).at(3));
      await tester.pumpAndSettle();

      // Tap submit
      await tester.tap(find.text('Submit'));
      await tester.pumpAndSettle();

      expect(submittedRating, 4);
    });

    testWidgets('submit includes feedback text', (WidgetTester tester) async {
      String? submittedFeedback;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {
                submittedFeedback = feedback;
              },
              showFeedbackField: true,
            ),
          ),
        ),
      );

      // Select rating
      await tester.tap(find.byIcon(Icons.star_outline).at(3));
      await tester.pumpAndSettle();

      // Enter feedback
      await tester.enterText(find.byType(TextField), 'Great session!');
      await tester.pumpAndSettle();

      // Submit
      await tester.tap(find.text('Submit'));
      await tester.pumpAndSettle();

      expect(submittedFeedback, 'Great session!');
    });

    testWidgets('skip button calls onSkip', (WidgetTester tester) async {
      var skipped = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              onSkip: () {
                skipped = true;
              },
            ),
          ),
        ),
      );

      await tester.tap(find.text('Skip'));
      await tester.pumpAndSettle();

      expect(skipped, true);
    });

    testWidgets('submit button disabled without rating', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      final submitButton = tester.widget<ElevatedButton>(
        find.widgetWithText(ElevatedButton, 'Submit'),
      );

      expect(submitButton.onPressed, isNull);
    });

    testWidgets('submit button enabled with rating', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      // Select rating
      await tester.tap(find.byIcon(Icons.star_outline).first);
      await tester.pumpAndSettle();

      final submitButton = tester.widget<ElevatedButton>(
        find.widgetWithText(ElevatedButton, 'Submit'),
      );

      expect(submitButton.onPressed, isNotNull);
    });

    testWidgets('shows custom submit button text', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              submitButtonText: 'Send Rating',
            ),
          ),
        ),
      );

      expect(find.text('Send Rating'), findsOneWidget);
    });

    testWidgets('shows custom skip button text', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              skipButtonText: 'Maybe Later',
            ),
          ),
        ),
      );

      expect(find.text('Maybe Later'), findsOneWidget);
    });

    testWidgets('supports initial rating', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
              initialRating: 3,
            ),
          ),
        ),
      );

      // Should show 3 filled stars initially
      expect(find.byIcon(Icons.star), findsNWidgets(3));
    });

    testWidgets('shows color-coded star colors', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RatingModal(
              title: 'Rate',
              onRatingSubmit: (rating, feedback) {},
            ),
          ),
        ),
      );

      // Tap 1 star (red)
      await tester.tap(find.byIcon(Icons.star_outline).first);
      await tester.pumpAndSettle();

      // Tap 3 stars (yellow)
      await tester.tap(find.byIcon(Icons.star_outline).at(2));
      await tester.pumpAndSettle();

      // Tap 5 stars (green)
      await tester.tap(find.byIcon(Icons.star_outline).last);
      await tester.pumpAndSettle();

      // Colors should be different based on rating
      expect(find.byIcon(Icons.star), findsNWidgets(5));
    });

    testWidgets('closes dialog after submit', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => RatingModal(
                      title: 'Rate',
                      onRatingSubmit: (rating, feedback) {
                        Navigator.pop(context);
                      },
                    ),
                  );
                },
                child: const Text('Show Rating'),
              ),
            ),
          ),
        ),
      );

      // Open dialog
      await tester.tap(find.text('Show Rating'));
      await tester.pumpAndSettle();

      // Select rating and submit
      await tester.tap(find.byIcon(Icons.star_outline).at(3));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Submit'));
      await tester.pumpAndSettle();

      // Dialog should be closed
      expect(find.byType(RatingModal), findsNothing);
    });
  });
}