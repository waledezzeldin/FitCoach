import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/widgets/quota_indicator.dart';

void main() {
  group('QuotaIndicator Widget Tests', () {
    testWidgets('renders with message quota data', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 5,
              limit: 10,
            ),
          ),
        ),
      );

      expect(find.text('Messages'), findsOneWidget);
      expect(find.text('5/10'), findsOneWidget);
    });

    testWidgets('shows correct progress percentage', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 7,
              limit: 10,
            ),
          ),
        ),
      );

      final progress = tester.widget<LinearProgressIndicator>(
        find.byType(LinearProgressIndicator),
      );
      expect(progress.value, 0.7);
    });

    testWidgets('shows green color when usage is low', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 3,
              limit: 10,
            ),
          ),
        ),
      );

      final progress = tester.widget<LinearProgressIndicator>(
        find.byType(LinearProgressIndicator),
      );
      expect(progress.color, isNot(equals(Colors.red)));
    });

    testWidgets('shows warning color when usage is high', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 8,
              limit: 10,
            ),
          ),
        ),
      );

      final progress = tester.widget<LinearProgressIndicator>(
        find.byType(LinearProgressIndicator),
      );
      expect(progress.color, isNotNull);
    });

    testWidgets('shows danger color when quota exceeded', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 10,
              limit: 10,
            ),
          ),
        ),
      );

      expect(find.byIcon(Icons.warning), findsOneWidget);
    });

    testWidgets('displays unlimited for negative limit', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 100,
              limit: -1,
            ),
          ),
        ),
      );

      expect(find.text('Unlimited'), findsOneWidget);
    });

    testWidgets('shows video call quota correctly', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'videoCalls',
              used: 2,
              limit: 4,
            ),
          ),
        ),
      );

      expect(find.text('Video Calls'), findsOneWidget);
      expect(find.text('2/4'), findsOneWidget);
    });

    testWidgets('shows compact variant correctly', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 5,
              limit: 10,
              compact: true,
            ),
          ),
        ),
      );

      // Compact version should show less info
      final widget = tester.widget<SizedBox>(
        find.byType(SizedBox),
      );
      expect(widget, isNotNull);
    });

    testWidgets('shows remaining count', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 7,
              limit: 10,
              showRemaining: true,
            ),
          ),
        ),
      );

      expect(find.textContaining('3 remaining'), findsOneWidget);
    });

    testWidgets('calls onTap when tapped', (WidgetTester tester) async {
      var tapped = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 5,
              limit: 10,
              onTap: () {
                tapped = true;
              },
            ),
          ),
        ),
      );

      await tester.tap(find.byType(QuotaIndicator));
      expect(tapped, true);
    });

    testWidgets('shows upgrade prompt when limit reached', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 10,
              limit: 10,
              showUpgradePrompt: true,
            ),
          ),
        ),
      );

      expect(find.text('Upgrade'), findsOneWidget);
    });

    testWidgets('hides upgrade prompt for unlimited', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 100,
              limit: -1,
              showUpgradePrompt: true,
            ),
          ),
        ),
      );

      expect(find.text('Upgrade'), findsNothing);
    });

    testWidgets('shows custom label when provided', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 5,
              limit: 10,
              customLabel: 'Chat Messages',
            ),
          ),
        ),
      );

      expect(find.text('Chat Messages'), findsOneWidget);
    });

    testWidgets('animates progress changes', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: QuotaIndicator(
              type: 'messages',
              used: 3,
              limit: 10,
              animated: true,
            ),
          ),
        ),
      );

      // Should have animation
      expect(find.byType(LinearProgressIndicator), findsOneWidget);
    });
  });
}