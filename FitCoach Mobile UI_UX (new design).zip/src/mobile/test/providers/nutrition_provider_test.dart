import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/providers/nutrition_provider.dart';
import 'package:fitcoach_mobile/presentation/providers/auth_provider.dart';

void main() {
  group('NutritionProvider Tests', () {
    late NutritionProvider nutritionProvider;
    late AuthProvider authProvider;

    setUp(() {
      authProvider = AuthProvider();
      nutritionProvider = NutritionProvider();
    });

    test('initial state should have no meal plan', () {
      expect(nutritionProvider.dailyMealPlan, isEmpty);
      expect(nutritionProvider.macroTargets, isEmpty);
      expect(nutritionProvider.isLoading, false);
    });

    test('loadNutritionPlan should fetch meal plan', () async {
      await nutritionProvider.loadNutritionPlan();

      expect(nutritionProvider.dailyMealPlan, isNotEmpty);
      expect(nutritionProvider.macroTargets, isNotEmpty);
      expect(nutritionProvider.macroTargets['calories'], greaterThan(0));
    });

    test('macroTargets should have all required fields', () async {
      await nutritionProvider.loadNutritionPlan();

      expect(nutritionProvider.macroTargets.containsKey('calories'), true);
      expect(nutritionProvider.macroTargets.containsKey('protein'), true);
      expect(nutritionProvider.macroTargets.containsKey('carbs'), true);
      expect(nutritionProvider.macroTargets.containsKey('fat'), true);
    });

    test('getCurrentMacros should calculate consumed macros', () async {
      await nutritionProvider.loadNutritionPlan();

      final currentMacros = nutritionProvider.getCurrentMacros();
      expect(currentMacros['calories'], greaterThanOrEqualTo(0));
      expect(currentMacros['protein'], greaterThanOrEqualTo(0));
      expect(currentMacros['carbs'], greaterThanOrEqualTo(0));
      expect(currentMacros['fat'], greaterThanOrEqualTo(0));
    });

    test('getRemainingMacros should calculate remaining values', () async {
      await nutritionProvider.loadNutritionPlan();

      final remaining = nutritionProvider.getRemainingMacros();
      expect(remaining['calories'], lessThanOrEqualTo(nutritionProvider.macroTargets['calories']));
    });

    test('markMealComplete should update meal status', () async {
      await nutritionProvider.loadNutritionPlan();

      final mealId = nutritionProvider.dailyMealPlan[0]['id'];
      await nutritionProvider.markMealComplete(mealId);

      final meal = nutritionProvider.dailyMealPlan.firstWhere((m) => m['id'] == mealId);
      expect(meal['completed'], true);
    });

    test('getMealProgress should calculate completion percentage', () async {
      await nutritionProvider.loadNutritionPlan();

      final progress = nutritionProvider.getMealProgress();
      expect(progress, greaterThanOrEqualTo(0));
      expect(progress, lessThanOrEqualTo(100));
    });

    test('checkFreemiumAccess for freemium tier', () async {
      // Simulate freemium user
      final trialStartDate = DateTime.now().subtract(const Duration(days: 5));
      final hasAccess = nutritionProvider.checkFreemiumAccess(
        'freemium',
        trialStartDate,
      );

      expect(hasAccess, true);
    });

    test('checkFreemiumAccess should deny after 14 days', () async {
      final trialStartDate = DateTime.now().subtract(const Duration(days: 15));
      final hasAccess = nutritionProvider.checkFreemiumAccess(
        'freemium',
        trialStartDate,
      );

      expect(hasAccess, false);
    });

    test('checkFreemiumAccess for premium tier should always allow', () async {
      final trialStartDate = DateTime.now().subtract(const Duration(days: 100));
      final hasAccess = nutritionProvider.checkFreemiumAccess(
        'premium',
        trialStartDate,
      );

      expect(hasAccess, true);
    });

    test('getRemainingTrialDays should calculate correctly', () async {
      final trialStartDate = DateTime.now().subtract(const Duration(days: 7));
      final remaining = nutritionProvider.getRemainingTrialDays(trialStartDate);

      expect(remaining, 7);
    });

    test('getRemainingTrialDays should return 0 after expiry', () async {
      final trialStartDate = DateTime.now().subtract(const Duration(days: 20));
      final remaining = nutritionProvider.getRemainingTrialDays(trialStartDate);

      expect(remaining, 0);
    });

    test('addCustomFood should add food to meal', () async {
      await nutritionProvider.loadNutritionPlan();

      final customFood = {
        'name': 'Custom Protein Shake',
        'calories': 200,
        'protein': 30,
        'carbs': 10,
        'fat': 5,
      };

      await nutritionProvider.addCustomFood('breakfast', customFood);

      final breakfast = nutritionProvider.dailyMealPlan.firstWhere(
        (m) => m['type'] == 'breakfast',
      );
      expect(breakfast['foods'].any((f) => f['name'] == customFood['name']), true);
    });

    test('getMealByType should return correct meal', () async {
      await nutritionProvider.loadNutritionPlan();

      final breakfast = nutritionProvider.getMealByType('breakfast');
      expect(breakfast, isNotNull);
      expect(breakfast?['type'], 'breakfast');
    });

    test('getCalorieProgress should return percentage', () async {
      await nutritionProvider.loadNutritionPlan();

      final progress = nutritionProvider.getCalorieProgress();
      expect(progress, greaterThanOrEqualTo(0));
      expect(progress, lessThanOrEqualTo(100));
    });

    test('isOverMacroLimit should detect overconsumption', () async {
      await nutritionProvider.loadNutritionPlan();

      // Add excessive calories
      final hugeMeal = {
        'name': 'Huge Meal',
        'calories': 10000,
        'protein': 100,
        'carbs': 100,
        'fat': 100,
      };
      await nutritionProvider.addCustomFood('lunch', hugeMeal);

      expect(nutritionProvider.isOverMacroLimit('calories'), true);
    });

    test('resetDailyTracking should clear meal completions', () async {
      await nutritionProvider.loadNutritionPlan();

      // Mark meals complete
      for (var meal in nutritionProvider.dailyMealPlan) {
        await nutritionProvider.markMealComplete(meal['id']);
      }

      // Reset
      await nutritionProvider.resetDailyTracking();

      final progress = nutritionProvider.getMealProgress();
      expect(progress, 0);
    });

    test('error handling should set error state', () async {
      // Test error handling
      nutritionProvider.loadNutritionPlan();
      expect(nutritionProvider.isLoading, false);
    });

    test('notifyListeners should be called on state changes', () async {
      var notified = false;
      nutritionProvider.addListener(() {
        notified = true;
      });

      await nutritionProvider.loadNutritionPlan();
      expect(notified, true);
    });
  });
}