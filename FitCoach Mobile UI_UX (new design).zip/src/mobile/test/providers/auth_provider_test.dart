import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/providers/auth_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('AuthProvider Tests', () {
    late AuthProvider authProvider;

    setUp(() {
      SharedPreferences.setMockInitialValues({});
      authProvider = AuthProvider();
    });

    test('initial state should be unauthenticated', () {
      expect(authProvider.isAuthenticated, false);
      expect(authProvider.user, null);
      expect(authProvider.token, null);
    });

    test('sendOTP should validate phone number', () async {
      // Valid Saudi phone numbers
      expect(await authProvider.sendOTP('+966501234567'), true);
      expect(await authProvider.sendOTP('+966551234567'), true);

      // Invalid phone numbers
      expect(await authProvider.sendOTP('+966401234567'), false);
      expect(await authProvider.sendOTP('501234567'), false);
      expect(await authProvider.sendOTP('+966'), false);
    });

    test('verifyOTP should authenticate user with correct OTP', () async {
      // Send OTP first
      await authProvider.sendOTP('+966501234567');

      // Verify with correct OTP (simulated)
      final result = await authProvider.verifyOTP('1234');
      expect(result, true);
      expect(authProvider.isAuthenticated, true);
      expect(authProvider.user, isNotNull);
      expect(authProvider.token, isNotNull);
    });

    test('verifyOTP should fail with incorrect OTP', () async {
      await authProvider.sendOTP('+966501234567');

      final result = await authProvider.verifyOTP('0000');
      expect(result, false);
      expect(authProvider.isAuthenticated, false);
    });

    test('logout should clear authentication state', () async {
      // Authenticate first
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('1234');
      expect(authProvider.isAuthenticated, true);

      // Logout
      await authProvider.logout();
      expect(authProvider.isAuthenticated, false);
      expect(authProvider.user, null);
      expect(authProvider.token, null);
    });

    test('updateProfile should update user data', () async {
      // Authenticate first
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('1234');

      // Update profile
      await authProvider.updateProfile({
        'name': 'Ahmed Ali',
        'age': 25,
      });

      expect(authProvider.user?['name'], 'Ahmed Ali');
      expect(authProvider.user?['age'], 25);
    });

    test('completeFirstIntake should save intake data', () async {
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('1234');

      final intakeData = {
        'goal': 'fat_loss',
        'experience': 'beginner',
        'height': 175,
        'weight': 80,
        'injuries': [],
      };

      await authProvider.completeFirstIntake(intakeData);
      expect(authProvider.user?['firstIntakeCompleted'], true);
    });

    test('completeSecondIntake should save detailed intake data', () async {
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('1234');
      await authProvider.completeFirstIntake({'goal': 'fat_loss'});

      final intakeData = {
        'workoutPreference': 'gym',
        'dietRestrictions': ['none'],
        'sleepHours': 7,
        'stressLevel': 'medium',
        'medications': [],
        'previousInjuries': [],
      };

      await authProvider.completeSecondIntake(intakeData);
      expect(authProvider.user?['secondIntakeCompleted'], true);
    });

    test('isLoading should be true during async operations', () async {
      expect(authProvider.isLoading, false);

      final future = authProvider.sendOTP('+966501234567');
      expect(authProvider.isLoading, true);

      await future;
      expect(authProvider.isLoading, false);
    });

    test('error should be set on authentication failure', () async {
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('wrong');

      expect(authProvider.error, isNotNull);
    });

    test('clearError should reset error state', () async {
      await authProvider.sendOTP('+966501234567');
      await authProvider.verifyOTP('wrong');
      expect(authProvider.error, isNotNull);

      authProvider.clearError();
      expect(authProvider.error, null);
    });
  });
}