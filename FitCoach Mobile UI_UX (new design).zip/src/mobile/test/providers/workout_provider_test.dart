import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/providers/workout_provider.dart';

void main() {
  group('WorkoutProvider Tests', () {
    late WorkoutProvider workoutProvider;

    setUp(() {
      workoutProvider = WorkoutProvider();
    });

    test('initial state should have empty workout plan', () {
      expect(workoutProvider.weeklyWorkouts, isEmpty);
      expect(workoutProvider.currentPlan, null);
      expect(workoutProvider.isLoading, false);
    });

    test('loadWorkoutPlan should fetch and set workout data', () async {
      await workoutProvider.loadWorkoutPlan();

      expect(workoutProvider.weeklyWorkouts, isNotEmpty);
      expect(workoutProvider.weeklyWorkouts.length, 7);
      expect(workoutProvider.currentPlan, isNotNull);
      expect(workoutProvider.isLoading, false);
    });

    test('getWorkoutForDay should return correct workout', () async {
      await workoutProvider.loadWorkoutPlan();

      final mondayWorkout = workoutProvider.getWorkoutForDay('monday');
      expect(mondayWorkout, isNotNull);
      expect(mondayWorkout?['exercises'], isNotEmpty);
    });

    test('markExerciseComplete should update completion status', () async {
      await workoutProvider.loadWorkoutPlan();

      final exerciseId = workoutProvider.weeklyWorkouts['monday']?['exercises'][0]['id'];
      await workoutProvider.markExerciseComplete(exerciseId);

      final exercise = workoutProvider.weeklyWorkouts['monday']?['exercises']
          .firstWhere((e) => e['id'] == exerciseId);
      expect(exercise['completed'], true);
    });

    test('getSubstitution should return alternative exercise', () async {
      await workoutProvider.loadWorkoutPlan();

      final originalExercise = 'Bench Press';
      final injury = 'shoulder';
      final substitution = await workoutProvider.getSubstitution(
        originalExercise,
        injury,
      );

      expect(substitution, isNotNull);
      expect(substitution?['name'], isNotEmpty);
      expect(substitution?['reason'], contains('shoulder'));
    });

    test('checkInjuryConflicts should detect conflicts', () async {
      await workoutProvider.loadWorkoutPlan();

      final injuries = ['shoulder', 'knee'];
      final conflicts = await workoutProvider.checkInjuryConflicts(injuries);

      expect(conflicts, isNotEmpty);
      expect(conflicts.first['affectedArea'], isIn(injuries));
    });

    test('applySubstitution should replace exercise', () async {
      await workoutProvider.loadWorkoutPlan();

      final originalExerciseId = workoutProvider.weeklyWorkouts['monday']?['exercises'][0]['id'];
      final substitution = {
        'id': 'sub_1',
        'name': 'Substitute Exercise',
        'sets': 3,
        'reps': 12,
      };

      await workoutProvider.applySubstitution(originalExerciseId, substitution);

      final exercise = workoutProvider.weeklyWorkouts['monday']?['exercises']
          .firstWhere((e) => e['id'] == substitution['id']);
      expect(exercise['name'], substitution['name']);
    });

    test('getWeeklyProgress should calculate completion percentage', () async {
      await workoutProvider.loadWorkoutPlan();

      // Mark some exercises as complete
      final exercises = workoutProvider.weeklyWorkouts['monday']?['exercises'];
      await workoutProvider.markExerciseComplete(exercises[0]['id']);

      final progress = workoutProvider.getWeeklyProgress();
      expect(progress, greaterThan(0));
      expect(progress, lessThanOrEqualTo(100));
    });

    test('getDayCompletion should return day-specific completion', () async {
      await workoutProvider.loadWorkoutPlan();

      final completion = workoutProvider.getDayCompletion('monday');
      expect(completion, greaterThanOrEqualTo(0));
      expect(completion, lessThanOrEqualTo(100));
    });

    test('resetWeek should clear all completions', () async {
      await workoutProvider.loadWorkoutPlan();

      // Mark exercises as complete
      final exercises = workoutProvider.weeklyWorkouts['monday']?['exercises'];
      await workoutProvider.markExerciseComplete(exercises[0]['id']);

      // Reset
      await workoutProvider.resetWeek();

      final completion = workoutProvider.getWeeklyProgress();
      expect(completion, 0);
    });

    test('isRestDay should correctly identify rest days', () async {
      await workoutProvider.loadWorkoutPlan();

      // Typically Sunday is a rest day
      expect(workoutProvider.isRestDay('sunday'), true);
      expect(workoutProvider.isRestDay('monday'), false);
    });

    test('getTodayWorkout should return current day workout', () async {
      await workoutProvider.loadWorkoutPlan();

      final todayWorkout = workoutProvider.getTodayWorkout();
      expect(todayWorkout, isNotNull);
    });

    test('error handling should set error state', () async {
      // Simulate error by passing invalid data
      workoutProvider.loadWorkoutPlan();
      
      // Error should be handled gracefully
      expect(workoutProvider.isLoading, false);
    });

    test('notifyListeners should be called on state changes', () async {
      var notified = false;
      workoutProvider.addListener(() {
        notified = true;
      });

      await workoutProvider.loadWorkoutPlan();
      expect(notified, true);
    });
  });
}