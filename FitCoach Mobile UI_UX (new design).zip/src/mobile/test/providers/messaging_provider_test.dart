import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/providers/messaging_provider.dart';
import 'package:fitcoach_mobile/presentation/providers/quota_provider.dart';

void main() {
  group('MessagingProvider Tests', () {
    late MessagingProvider messagingProvider;
    late QuotaProvider quotaProvider;

    setUp(() {
      quotaProvider = QuotaProvider();
      messagingProvider = MessagingProvider();
    });

    test('initial state should have empty messages', () {
      expect(messagingProvider.messages, isEmpty);
      expect(messagingProvider.isConnected, false);
      expect(messagingProvider.isTyping, false);
    });

    test('connect should establish socket connection', () async {
      await messagingProvider.connect('user123', 'coach456');

      expect(messagingProvider.isConnected, true);
      expect(messagingProvider.currentChatId, isNotEmpty);
    });

    test('disconnect should close socket connection', () async {
      await messagingProvider.connect('user123', 'coach456');
      expect(messagingProvider.isConnected, true);

      await messagingProvider.disconnect();
      expect(messagingProvider.isConnected, false);
    });

    test('sendMessage should add message to list', () async {
      await messagingProvider.connect('user123', 'coach456');

      await messagingProvider.sendMessage('Test message');

      expect(messagingProvider.messages, isNotEmpty);
      expect(messagingProvider.messages.last['text'], 'Test message');
      expect(messagingProvider.messages.last['sender'], 'user');
    });

    test('sendMessage should check quota before sending', () async {
      await messagingProvider.connect('user123', 'coach456');
      
      // Max out quota
      quotaProvider.quotas['messages']['used'] = 
          quotaProvider.quotas['messages']['limit'];

      final result = await messagingProvider.sendMessage('Test');
      expect(result, false);
    });

    test('receiveMessage should add coach message', () async {
      await messagingProvider.connect('user123', 'coach456');

      messagingProvider.receiveMessage({
        'id': 'msg1',
        'text': 'Coach response',
        'sender': 'coach',
        'timestamp': DateTime.now().toIso8601String(),
      });

      expect(messagingProvider.messages.last['sender'], 'coach');
      expect(messagingProvider.messages.last['text'], 'Coach response');
    });

    test('setTypingStatus should update typing indicator', () {
      messagingProvider.setTypingStatus(true);
      expect(messagingProvider.isTyping, true);

      messagingProvider.setTypingStatus(false);
      expect(messagingProvider.isTyping, false);
    });

    test('markAsRead should update read status', () async {
      await messagingProvider.connect('user123', 'coach456');
      await messagingProvider.sendMessage('Test');

      final messageId = messagingProvider.messages.last['id'];
      await messagingProvider.markAsRead(messageId);

      expect(messagingProvider.messages.last['read'], true);
    });

    test('loadMessageHistory should fetch previous messages', () async {
      await messagingProvider.loadMessageHistory('chat123');

      expect(messagingProvider.messages, isNotEmpty);
      expect(messagingProvider.isLoading, false);
    });

    test('sendAttachment should check Premium+ tier', () async {
      await messagingProvider.connect('user123', 'coach456');

      // Freemium user
      quotaProvider.currentTier = 'freemium';
      final freemiumResult = await messagingProvider.sendAttachment('image.jpg');
      expect(freemiumResult, false);

      // Smart Premium user
      quotaProvider.currentTier = 'smart_premium';
      final premiumResult = await messagingProvider.sendAttachment('image.jpg');
      expect(premiumResult, true);
    });

    test('getUnreadCount should return correct count', () async {
      await messagingProvider.connect('user123', 'coach456');

      // Add unread messages
      messagingProvider.receiveMessage({
        'id': 'msg1',
        'text': 'Message 1',
        'sender': 'coach',
        'read': false,
      });
      messagingProvider.receiveMessage({
        'id': 'msg2',
        'text': 'Message 2',
        'sender': 'coach',
        'read': false,
      });

      expect(messagingProvider.getUnreadCount(), 2);
    });

    test('searchMessages should filter by query', () async {
      await messagingProvider.loadMessageHistory('chat123');

      final results = messagingProvider.searchMessages('workout');
      expect(results.every((msg) => 
        msg['text'].toLowerCase().contains('workout')), true);
    });

    test('deleteMessage should remove from list', () async {
      await messagingProvider.connect('user123', 'coach456');
      await messagingProvider.sendMessage('Test');

      final messageId = messagingProvider.messages.last['id'];
      await messagingProvider.deleteMessage(messageId);

      expect(messagingProvider.messages.any((m) => m['id'] == messageId), false);
    });

    test('clearChat should remove all messages', () async {
      await messagingProvider.connect('user123', 'coach456');
      await messagingProvider.sendMessage('Message 1');
      await messagingProvider.sendMessage('Message 2');

      await messagingProvider.clearChat();
      expect(messagingProvider.messages, isEmpty);
    });

    test('error handling should set error state', () async {
      // Simulate connection error
      await messagingProvider.connect('invalid', 'invalid');

      expect(messagingProvider.error, isNotNull);
      expect(messagingProvider.isConnected, false);
    });

    test('reconnect should re-establish connection', () async {
      await messagingProvider.connect('user123', 'coach456');
      await messagingProvider.disconnect();

      await messagingProvider.reconnect();
      expect(messagingProvider.isConnected, true);
    });

    test('notifyListeners should be called on state changes', () async {
      var notified = false;
      messagingProvider.addListener(() {
        notified = true;
      });

      await messagingProvider.sendMessage('Test');
      expect(notified, true);
    });
  });
}