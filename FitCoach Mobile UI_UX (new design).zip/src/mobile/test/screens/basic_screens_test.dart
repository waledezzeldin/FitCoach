import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fitcoach_mobile/presentation/screens/onboarding_screen.dart';
import 'package:fitcoach_mobile/presentation/screens/splash_screen.dart';
import 'package:fitcoach_mobile/presentation/screens/language_selection_screen.dart';

void main() {
  group('Screen Widget Tests', () {
    testWidgets('SplashScreen renders correctly', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: SplashScreen(),
        ),
      );

      // Splash screen should render
      expect(find.byType(SplashScreen), findsOneWidget);
    });

    testWidgets('OnboardingScreen renders correctly', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: OnboardingScreen(),
        ),
      );

      // Onboarding screen should render
      expect(find.byType(OnboardingScreen), findsOneWidget);
    });

    testWidgets('LanguageSelectionScreen renders correctly', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: LanguageSelectionScreen(),
        ),
      );

      // Language selection screen should render
      expect(find.byType(LanguageSelectionScreen), findsOneWidget);
    });
  });
}