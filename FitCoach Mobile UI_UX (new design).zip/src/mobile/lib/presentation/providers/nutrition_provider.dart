import 'package:flutter/material.dart';
import '../../data/repositories/nutrition_repository.dart';
import '../../data/models/nutrition_plan.dart';

class NutritionProvider extends ChangeNotifier {
  final NutritionRepository _repository;
  
  NutritionPlan? _activePlan;
  bool _isLoading = false;
  String? _error;
  DateTime? _trialStartDate;
  int _trialDaysRemaining = 0;
  bool _hasTrialExpired = false;
  
  // Freemium users get 14-day trial
  static const int freemiumTrialDays = 14;
  
  NutritionProvider(this._repository);
  
  // Getters
  NutritionPlan? get activePlan => _activePlan;
  bool get isLoading => _isLoading;
  String? get error => _error;
  DateTime? get trialStartDate => _trialStartDate;
  int get trialDaysRemaining => _trialDaysRemaining;
  bool get hasTrialExpired => _hasTrialExpired;
  
  // Load active nutrition plan
  Future<void> loadActivePlan() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final plan = await _repository.getActivePlan();
      _activePlan = plan;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
  
  // Check trial status for Freemium users
  Future<void> checkTrialStatus() async {
    try {
      final trialData = await _repository.getTrialStatus();
      
      _trialStartDate = trialData['startDate'] != null
          ? DateTime.parse(trialData['startDate'] as String)
          : null;
      
      if (_trialStartDate != null) {
        final daysSinceStart = DateTime.now().difference(_trialStartDate!).inDays;
        _trialDaysRemaining = freemiumTrialDays - daysSinceStart;
        _hasTrialExpired = _trialDaysRemaining <= 0;
      }
      
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
  
  // Check if user can access nutrition (Premium+ or Freemium within trial)
  bool canAccessNutrition(String subscriptionTier) {
    if (subscriptionTier == 'Premium' || subscriptionTier == 'Smart Premium') {
      return true;
    }
    
    // Freemium users - check trial
    return !_hasTrialExpired;
  }
  
  // Log meal consumption
  Future<bool> logMeal(String mealId, Map<String, dynamic> data) async {
    try {
      await _repository.logMeal(mealId, data);
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Get nutrition history
  Future<List<Map<String, dynamic>>> getNutritionHistory() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final history = await _repository.getNutritionHistory();
      _isLoading = false;
      notifyListeners();
      return history;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }
  
  // Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
