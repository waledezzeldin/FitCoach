import 'package:flutter/material.dart';
import '../../data/repositories/user_repository.dart';

class QuotaProvider extends ChangeNotifier {
  final UserRepository _repository;
  
  int _messagesUsed = 0;
  int _messagesLimit = 0;
  int _videoCallsUsed = 0;
  int _videoCallsLimit = 0;
  bool _isLoading = false;
  String? _error;
  
  // Quota limits by tier
  static const Map<String, Map<String, int>> quotaLimits = {
    'Freemium': {
      'messages': 20,
      'videoCalls': 1,
    },
    'Premium': {
      'messages': 200,
      'videoCalls': 2,
    },
    'Smart Premium': {
      'messages': -1, // Unlimited
      'videoCalls': 4,
    },
  };
  
  QuotaProvider(this._repository);
  
  // Getters
  int get messagesUsed => _messagesUsed;
  int get messagesLimit => _messagesLimit;
  int get messagesRemaining => 
      _messagesLimit == -1 ? -1 : _messagesLimit - _messagesUsed;
  
  int get videoCallsUsed => _videoCallsUsed;
  int get videoCallsLimit => _videoCallsLimit;
  int get videoCallsRemaining => _videoCallsLimit - _videoCallsUsed;
  
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  bool get hasMessagesRemaining => 
      _messagesLimit == -1 || messagesRemaining > 0;
  
  bool get hasVideoCallsRemaining => videoCallsRemaining > 0;
  
  double get messagesUsagePercentage {
    if (_messagesLimit == -1) return 0; // Unlimited
    if (_messagesLimit == 0) return 0;
    return (_messagesUsed / _messagesLimit).clamp(0.0, 1.0);
  }
  
  double get videoCallsUsagePercentage {
    if (_videoCallsLimit == 0) return 0;
    return (_videoCallsUsed / _videoCallsLimit).clamp(0.0, 1.0);
  }
  
  // Load quota usage
  Future<void> loadQuota() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final quotaData = await _repository.getQuotaUsage();
      
      _messagesUsed = quotaData['messagesUsed'] as int? ?? 0;
      _messagesLimit = quotaData['messagesLimit'] as int? ?? 0;
      _videoCallsUsed = quotaData['videoCallsUsed'] as int? ?? 0;
      _videoCallsLimit = quotaData['videoCallsLimit'] as int? ?? 0;
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
  
  // Set quota limits based on subscription tier
  void setLimitsForTier(String tier) {
    final limits = quotaLimits[tier];
    
    if (limits != null) {
      _messagesLimit = limits['messages'] ?? 0;
      _videoCallsLimit = limits['videoCalls'] ?? 0;
      notifyListeners();
    }
  }
  
  // Increment message count
  void incrementMessageCount() {
    _messagesUsed++;
    notifyListeners();
  }
  
  // Increment video call count
  void incrementVideoCallCount() {
    _videoCallsUsed++;
    notifyListeners();
  }
  
  // Check if user can send message
  bool canSendMessage() {
    return hasMessagesRemaining;
  }
  
  // Check if user can make video call
  bool canMakeVideoCall() {
    return hasVideoCallsRemaining;
  }
  
  // Get warning message for quota
  String? getQuotaWarningMessage(String type) {
    if (type == 'message') {
      if (!hasMessagesRemaining) {
        return 'Message quota exceeded. Upgrade to send more messages.';
      }
      if (messagesRemaining <= 5 && messagesRemaining > 0) {
        return '$messagesRemaining messages remaining this month.';
      }
    } else if (type == 'videoCall') {
      if (!hasVideoCallsRemaining) {
        return 'Video call quota exceeded. Upgrade for more calls.';
      }
      if (videoCallsRemaining == 1) {
        return '1 video call remaining this month.';
      }
    }
    return null;
  }
  
  // Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
