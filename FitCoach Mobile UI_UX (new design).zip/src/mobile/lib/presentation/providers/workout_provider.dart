import 'package:flutter/material.dart';
import '../../data/repositories/workout_repository.dart';
import '../../data/models/workout_plan.dart';

class WorkoutProvider extends ChangeNotifier {
  final WorkoutRepository _repository;
  
  WorkoutPlan? _activePlan;
  List<Exercise> _exerciseLibrary = [];
  bool _isLoading = false;
  String? _error;
  int? _currentDayIndex;
  Map<String, bool> _completedExercises = {};
  
  WorkoutProvider(this._repository);
  
  // Getters
  WorkoutPlan? get activePlan => _activePlan;
  List<Exercise> get exerciseLibrary => _exerciseLibrary;
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get currentDayIndex => _currentDayIndex;
  
  WorkoutDay? get currentDay {
    if (_activePlan == null || _currentDayIndex == null) return null;
    if (_currentDayIndex! >= _activePlan!.days.length) return null;
    return _activePlan!.days[_currentDayIndex!];
  }
  
  // Load active workout plan
  Future<void> loadActivePlan() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final plan = await _repository.getActivePlan();
      _activePlan = plan;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
  
  // Load exercise library
  Future<void> loadExerciseLibrary() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final exercises = await _repository.getExerciseLibrary();
      _exerciseLibrary = exercises;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
  
  // Set current day
  void setCurrentDay(int dayIndex) {
    _currentDayIndex = dayIndex;
    notifyListeners();
  }
  
  // Mark exercise as completed
  Future<bool> completeExercise(String exerciseId) async {
    try {
      await _repository.markExerciseComplete(exerciseId);
      _completedExercises[exerciseId] = true;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Get exercise alternatives (for injury substitution)
  Future<List<Exercise>> getExerciseAlternatives(
    String exerciseId,
    List<String> userInjuries,
  ) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final alternatives = await _repository.getExerciseAlternatives(
        exerciseId,
        userInjuries,
      );
      _isLoading = false;
      notifyListeners();
      return alternatives;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return [];
    }
  }
  
  // Substitute exercise
  Future<bool> substituteExercise(
    String originalExerciseId,
    String newExerciseId,
  ) async {
    try {
      await _repository.substituteExercise(
        originalExerciseId,
        newExerciseId,
      );
      
      // Reload the plan to reflect changes
      await loadActivePlan();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Log workout session
  Future<bool> logWorkout(Map<String, dynamic> workoutData) async {
    try {
      await _repository.logWorkout(workoutData);
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Check if exercise is completed
  bool isExerciseCompleted(String exerciseId) {
    return _completedExercises[exerciseId] ?? false;
  }
  
  // Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
}
