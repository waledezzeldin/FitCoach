import 'package:flutter/material.dart';
import '../../data/repositories/messaging_repository.dart';
import '../../data/models/message.dart';

class MessagingProvider extends ChangeNotifier {
  final MessagingRepository _repository;
  
  List<Message> _messages = [];
  Conversation? _activeConversation;
  bool _isLoading = false;
  String? _error;
  bool _isConnected = false;
  
  MessagingProvider(this._repository) {
    _initializeSocket();
  }
  
  // Getters
  List<Message> get messages => _messages;
  Conversation? get activeConversation => _activeConversation;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isConnected => _isConnected;
  
  // Initialize Socket.IO connection
  Future<void> _initializeSocket() async {
    try {
      await _repository.connect();
      _isConnected = true;
      
      // Listen for new messages
      _repository.onMessageReceived((message) {
        _messages.add(message);
        notifyListeners();
      });
      
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isConnected = false;
      notifyListeners();
    }
  }
  
  // Load conversation
  Future<void> loadConversation(String conversationId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final conversation = await _repository.getConversation(conversationId);
      _activeConversation = conversation;
      
      final messages = await _repository.getMessages(conversationId);
      _messages = messages;
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
  
  // Send message
  Future<bool> sendMessage(String content, {MessageType type = MessageType.text}) async {
    if (_activeConversation == null) {
      _error = 'No active conversation';
      notifyListeners();
      return false;
    }
    
    try {
      final message = await _repository.sendMessage(
        _activeConversation!.id,
        content,
        type: type,
      );
      
      _messages.add(message);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Send message with attachment (Premium+ only)
  Future<bool> sendMessageWithAttachment(
    String content,
    String filePath,
    MessageType type,
  ) async {
    if (_activeConversation == null) {
      _error = 'No active conversation';
      notifyListeners();
      return false;
    }
    
    try {
      final message = await _repository.sendMessageWithAttachment(
        _activeConversation!.id,
        content,
        filePath,
        type: type,
      );
      
      _messages.add(message);
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Mark messages as read
  Future<void> markAsRead(String messageId) async {
    try {
      await _repository.markAsRead(messageId);
      
      // Update local message
      final index = _messages.indexWhere((m) => m.id == messageId);
      if (index != -1) {
        // Create updated message (this is simplified - in real app use copyWith)
        notifyListeners();
      }
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
  
  // Get user conversations
  Future<List<Conversation>> getConversations() async {
    try {
      return await _repository.getConversations();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return [];
    }
  }
  
  // Disconnect socket
  void disconnect() {
    _repository.disconnect();
    _isConnected = false;
    notifyListeners();
  }
  
  // Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }
  
  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}
