import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../data/models/appointment.dart';
import '../../providers/language_provider.dart';
import '../../providers/video_call_provider.dart';
import '../../widgets/custom_button.dart';
import '../video_call/video_call_screen.dart';
import '../../../core/constants/colors.dart';

/// Appointment Detail Screen
/// Shows appointment details and allows joining video call
class AppointmentDetailScreen extends StatefulWidget {
  final Appointment appointment;

  const AppointmentDetailScreen({
    Key? key,
    required this.appointment,
  }) : super(key: key);

  @override
  State<AppointmentDetailScreen> createState() =>
      _AppointmentDetailScreenState();
}

class _AppointmentDetailScreenState extends State<AppointmentDetailScreen> {
  bool _isCheckingAccess = false;
  String? _accessMessage;
  bool _canJoin = false;

  @override
  void initState() {
    super.initState();
    _checkCanJoin();
  }

  Future<void> _checkCanJoin() async {
    setState(() {
      _isCheckingAccess = true;
    });

    final provider = Provider.of<VideoCallProvider>(context, listen: false);
    final result = await provider.canJoinCall(widget.appointment.id);

    if (result != null && result['canJoin'] == true) {
      setState(() {
        _canJoin = true;
        _accessMessage = null;
        _isCheckingAccess = false;
      });
    } else {
      setState(() {
        _canJoin = false;
        _accessMessage = result?['reason'] ?? 'Cannot join call at this time';
        _isCheckingAccess = false;
      });
    }
  }

  Future<void> _joinCall() async {
    final languageProvider =
        Provider.of<LanguageProvider>(context, listen: false);
    final isArabic = languageProvider.isArabic;

    // Navigate to video call screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VideoCallScreen(
          appointmentId: widget.appointment.id,
          coachId: widget.appointment.coachId,
          coachName: widget.appointment.coachName ?? 'Coach',
          isCoach: false,
        ),
      ),
    );
  }

  String _getStatusText(String status, bool isArabic) {
    switch (status) {
      case 'pending':
        return isArabic ? 'قيد الانتظار' : 'Pending';
      case 'confirmed':
        return isArabic ? 'مؤكد' : 'Confirmed';
      case 'in_progress':
        return isArabic ? 'جارٍ' : 'In Progress';
      case 'completed':
        return isArabic ? 'مكتمل' : 'Completed';
      case 'cancelled':
        return isArabic ? 'ملغى' : 'Cancelled';
      default:
        return status;
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'confirmed':
        return Colors.green;
      case 'in_progress':
        return Colors.blue;
      case 'completed':
        return Colors.grey;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = context.watch<LanguageProvider>();
    final isArabic = languageProvider.isArabic;

    final scheduledTime = DateTime.parse(widget.appointment.scheduledAt);
    final now = DateTime.now();
    final tenMinutesBefore = scheduledTime.subtract(const Duration(minutes: 10));
    final canJoinSoon = now.isAfter(tenMinutesBefore) &&
        widget.appointment.status == 'confirmed';

    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'تفاصيل الموعد' : 'Appointment Details'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: _getStatusColor(widget.appointment.status)
                    .withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: _getStatusColor(widget.appointment.status),
                  width: 1,
                ),
              ),
              child: Text(
                _getStatusText(widget.appointment.status, isArabic),
                style: TextStyle(
                  color: _getStatusColor(widget.appointment.status),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Coach info
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: AppColors.primary.withOpacity(0.2),
                      child: Icon(
                        Icons.person,
                        size: 30,
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isArabic ? 'المدرب' : 'Coach',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            widget.appointment.coachName ?? 'Coach',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Date & Time
            _buildDetailCard(
              icon: Icons.calendar_today,
              title: isArabic ? 'التاريخ والوقت' : 'Date & Time',
              value: DateFormat('EEEE, MMM d, y - h:mm a').format(scheduledTime),
            ),

            const SizedBox(height: 16),

            // Duration
            _buildDetailCard(
              icon: Icons.timer,
              title: isArabic ? 'المدة' : 'Duration',
              value: '${widget.appointment.durationMinutes ?? 30} ${isArabic ? 'دقيقة' : 'minutes'}',
            ),

            const SizedBox(height: 16),

            // Type
            if (widget.appointment.type != null)
              _buildDetailCard(
                icon: Icons.category,
                title: isArabic ? 'النوع' : 'Type',
                value: widget.appointment.type!,
              ),

            const SizedBox(height: 16),

            // Notes
            if (widget.appointment.notes != null &&
                widget.appointment.notes!.isNotEmpty)
              _buildDetailCard(
                icon: Icons.note,
                title: isArabic ? 'ملاحظات' : 'Notes',
                value: widget.appointment.notes!,
              ),

            const SizedBox(height: 24),

            // Join call button or message
            if (widget.appointment.status == 'confirmed')
              Column(
                children: [
                  if (_isCheckingAccess)
                    const Center(child: CircularProgressIndicator())
                  else if (_canJoin && canJoinSoon)
                    Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.green, width: 2),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.check_circle,
                                  color: Colors.green),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  isArabic
                                      ? 'يمكنك الانضمام الآن!'
                                      : 'You can join now!',
                                  style: const TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        CustomButton(
                          text: isArabic
                              ? 'انضم إلى المكالمة'
                              : 'Join Video Call',
                          onPressed: _joinCall,
                          icon: Icons.videocam,
                          backgroundColor: Colors.green,
                        ),
                      ],
                    )
                  else
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.orange),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.schedule, color: Colors.orange),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _accessMessage ??
                                  (isArabic
                                      ? 'يمكنك الانضمام قبل 10 دقائق من الموعد'
                                      : 'You can join 10 minutes before appointment'),
                              style: const TextStyle(color: Colors.orange),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),

            if (widget.appointment.status == 'pending')
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.hourglass_empty, color: Colors.orange),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        isArabic
                            ? 'في انتظار موافقة المدرب'
                            : 'Waiting for coach approval',
                        style: const TextStyle(color: Colors.orange),
                      ),
                    ),
                  ],
                ),
              ),

            if (widget.appointment.status == 'completed')
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.grey),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        isArabic ? 'الموعد مكتمل' : 'Appointment completed',
                        style: const TextStyle(color: Colors.grey),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailCard({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
