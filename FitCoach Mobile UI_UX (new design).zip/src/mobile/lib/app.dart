import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'presentation/providers/auth_provider.dart';
import 'presentation/providers/language_provider.dart';
import 'presentation/screens/splash_screen.dart';
import 'presentation/screens/language_selection_screen.dart';
import 'presentation/screens/onboarding_screen.dart';
import 'presentation/screens/auth/otp_auth_screen.dart';
import 'presentation/screens/intake/first_intake_screen.dart';
import 'presentation/screens/intake/second_intake_screen.dart';
import 'presentation/screens/home/home_dashboard_screen.dart';
import 'presentation/screens/workout/workout_screen.dart';
import 'presentation/screens/nutrition/nutrition_screen.dart';
import 'presentation/screens/messaging/coach_messaging_screen.dart';
import 'presentation/screens/store/store_screen.dart';
import 'presentation/screens/account/account_screen.dart';
import 'presentation/screens/coach/coach_dashboard.dart';
import 'presentation/screens/admin/admin_dashboard.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  bool _showSplash = true;
  String _currentScreen = 'splash';

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    // Show splash for 2 seconds
    await Future.delayed(const Duration(seconds: 2));
    
    if (!mounted) return;
    
    final languageProvider = context.read<LanguageProvider>();
    final authProvider = context.read<AuthProvider>();
    
    setState(() {
      _showSplash = false;
      
      // Determine initial screen
      if (!languageProvider.hasSelectedLanguage) {
        _currentScreen = 'language';
      } else if (!authProvider.isAuthenticated) {
        _currentScreen = 'onboarding';
      } else if (authProvider.user != null && 
                 !authProvider.user!.hasCompletedFirstIntake) {
        _currentScreen = 'firstIntake';
      } else {
        _currentScreen = 'home';
      }
    });
  }

  void _navigateToScreen(String screen) {
    setState(() {
      _currentScreen = screen;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showSplash) {
      return const SplashScreen();
    }

    return Consumer<AuthProvider>(
      builder: (context, authProvider, _) {
        // Auto-navigate based on auth state
        if (!authProvider.isAuthenticated && 
            _currentScreen != 'language' && 
            _currentScreen != 'onboarding' && 
            _currentScreen != 'auth') {
          Future.microtask(() => _navigateToScreen('auth'));
        }

        return _buildCurrentScreen();
      },
    );
  }

  Widget _buildCurrentScreen() {
    switch (_currentScreen) {
      case 'language':
        return LanguageSelectionScreen(
          onLanguageSelected: () => _navigateToScreen('onboarding'),
        );
      
      case 'onboarding':
        return OnboardingScreen(
          onComplete: () => _navigateToScreen('auth'),
        );
      
      case 'auth':
        return OTPAuthScreen(
          onAuthenticated: () => _navigateToScreen('firstIntake'),
        );
      
      case 'firstIntake':
        return FirstIntakeScreen(
          onComplete: () => _navigateToScreen('home'),
          onSkip: () => _navigateToScreen('home'),
        );
      
      case 'secondIntake':
        return SecondIntakeScreen(
          onComplete: () => _navigateToScreen('home'),
        );
      
      case 'home':
        return HomeDashboardScreen(
          onNavigate: _navigateToScreen,
        );
      
      case 'workout':
        return WorkoutScreen(
          onBack: () => _navigateToScreen('home'),
        );
      
      case 'nutrition':
        return NutritionScreen(
          onBack: () => _navigateToScreen('home'),
        );
      
      case 'coach':
        return CoachMessagingScreen(
          onBack: () => _navigateToScreen('home'),
        );
      
      case 'store':
        return StoreScreen(
          onBack: () => _navigateToScreen('home'),
        );
      
      case 'account':
        return AccountScreen(
          onBack: () => _navigateToScreen('home'),
          onNavigate: _navigateToScreen,
        );
      
      case 'coachDashboard':
        return CoachDashboard(
          onBack: () => _navigateToScreen('home'),
        );
      
      case 'adminDashboard':
        return AdminDashboard(
          onBack: () => _navigateToScreen('home'),
        );
      
      default:
        return HomeDashboardScreen(
          onNavigate: _navigateToScreen,
        );
    }
  }
}
