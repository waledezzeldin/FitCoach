const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { checkMessageQuota } = require('../middleware/quotaMiddleware');
const { chatAttachmentControl } = require('../middleware/chatAttachmentControl');
const messageController = require('../controllers/messageController');
const upload = require('../middleware/upload');

// Conversation routes
router.get('/conversations', authMiddleware, messageController.getConversations);
router.get('/conversations/:id', authMiddleware, messageController.getConversationMessages);

// Message routes
router.post('/', authMiddleware, checkMessageQuota, messageController.sendMessage);
router.put('/:id/read', authMiddleware, messageController.markAsRead);
router.delete('/:id', authMiddleware, messageController.deleteMessage);

// Attachment upload (Premium+ only for PDFs/files)
router.post(
  '/upload', 
  authMiddleware, 
  chatAttachmentControl, 
  upload.single('file'), 
  messageController.uploadAttachment
);

// Utility routes
router.get('/unread/count', authMiddleware, messageController.getUnreadCount);
router.get('/search', authMiddleware, messageController.searchMessages);

module.exports = router;