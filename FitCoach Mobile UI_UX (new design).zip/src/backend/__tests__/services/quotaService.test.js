const quotaService = require('../../src/services/quotaService');
const db = require('../../src/database');
const { createTestUser } = require('../helpers/testHelpers');

jest.mock('../../src/database');

describe('QuotaService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getQuotaLimits', () => {
    it('should return freemium limits', () => {
      const limits = quotaService.getQuotaLimits('freemium');

      expect(limits).toEqual({
        messages: 50,
        videoCalls: 0
      });
    });

    it('should return premium limits', () => {
      const limits = quotaService.getQuotaLimits('premium');

      expect(limits).toEqual({
        messages: -1, // unlimited
        videoCalls: 4
      });
    });

    it('should return smart_premium limits', () => {
      const limits = quotaService.getQuotaLimits('smart_premium');

      expect(limits).toEqual({
        messages: -1, // unlimited
        videoCalls: -1 // unlimited
      });
    });
  });

  describe('checkQuota', () => {
    it('should return true if quota available', async () => {
      const testUser = createTestUser({
        subscription_tier: 'freemium',
        messages_sent_this_month: 10
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const result = await quotaService.checkQuota(testUser.id, 'messages');

      expect(result).toBe(true);
    });

    it('should return false if quota exceeded', async () => {
      const testUser = createTestUser({
        subscription_tier: 'freemium',
        messages_sent_this_month: 50
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const result = await quotaService.checkQuota(testUser.id, 'messages');

      expect(result).toBe(false);
    });

    it('should return true for unlimited quota', async () => {
      const testUser = createTestUser({
        subscription_tier: 'premium',
        messages_sent_this_month: 1000
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const result = await quotaService.checkQuota(testUser.id, 'messages');

      expect(result).toBe(true);
    });

    it('should handle video calls quota', async () => {
      const testUser = createTestUser({
        subscription_tier: 'premium',
        video_calls_this_month: 2
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const result = await quotaService.checkQuota(testUser.id, 'videoCalls');

      expect(result).toBe(true);
    });

    it('should handle user not found', async () => {
      db.query.mockResolvedValue({ rows: [] });

      await expect(
        quotaService.checkQuota('non-existent', 'messages')
      ).rejects.toThrow('User not found');
    });
  });

  describe('incrementQuota', () => {
    it('should increment message quota', async () => {
      db.query.mockResolvedValue({ rowCount: 1 });

      await quotaService.incrementQuota('test-user-id', 'messages');

      expect(db.query).toHaveBeenCalledWith(
        expect.stringContaining('messages_sent_this_month'),
        ['test-user-id']
      );
    });

    it('should increment video call quota', async () => {
      db.query.mockResolvedValue({ rowCount: 1 });

      await quotaService.incrementQuota('test-user-id', 'videoCalls');

      expect(db.query).toHaveBeenCalledWith(
        expect.stringContaining('video_calls_this_month'),
        ['test-user-id']
      );
    });

    it('should handle database errors', async () => {
      db.query.mockRejectedValue(new Error('Database error'));

      await expect(
        quotaService.incrementQuota('test-user-id', 'messages')
      ).rejects.toThrow('Database error');
    });
  });

  describe('getQuotaStatus', () => {
    it('should return quota status for freemium user', async () => {
      const testUser = createTestUser({
        subscription_tier: 'freemium',
        messages_sent_this_month: 30,
        video_calls_this_month: 0
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const status = await quotaService.getQuotaStatus('test-user-id');

      expect(status).toEqual({
        tier: 'freemium',
        messages: {
          used: 30,
          limit: 50,
          remaining: 20,
          percentage: 60
        },
        videoCalls: {
          used: 0,
          limit: 0,
          remaining: 0,
          percentage: 0
        }
      });
    });

    it('should return quota status for premium user', async () => {
      const testUser = createTestUser({
        subscription_tier: 'premium',
        messages_sent_this_month: 100,
        video_calls_this_month: 2
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const status = await quotaService.getQuotaStatus('test-user-id');

      expect(status).toEqual({
        tier: 'premium',
        messages: {
          used: 100,
          limit: -1,
          remaining: -1,
          percentage: 0
        },
        videoCalls: {
          used: 2,
          limit: 4,
          remaining: 2,
          percentage: 50
        }
      });
    });

    it('should handle unlimited quota', async () => {
      const testUser = createTestUser({
        subscription_tier: 'smart_premium',
        messages_sent_this_month: 500,
        video_calls_this_month: 10
      });

      db.query.mockResolvedValue({ rows: [testUser] });

      const status = await quotaService.getQuotaStatus('test-user-id');

      expect(status.messages.remaining).toBe(-1);
      expect(status.videoCalls.remaining).toBe(-1);
    });
  });

  describe('resetQuota', () => {
    it('should reset user quota', async () => {
      db.query.mockResolvedValue({ rowCount: 1 });

      await quotaService.resetQuota('test-user-id');

      expect(db.query).toHaveBeenCalledWith(
        expect.stringContaining('messages_sent_this_month = 0'),
        expect.arrayContaining(['test-user-id'])
      );
    });

    it('should handle errors', async () => {
      db.query.mockRejectedValue(new Error('Database error'));

      await expect(
        quotaService.resetQuota('test-user-id')
      ).rejects.toThrow();
    });
  });

  describe('resetAllQuotas', () => {
    it('should reset all user quotas', async () => {
      db.query.mockResolvedValue({ rowCount: 10 });

      const result = await quotaService.resetAllQuotas();

      expect(db.query).toHaveBeenCalled();
      expect(result).toBe(10);
    });
  });
});
