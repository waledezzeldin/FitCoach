const authController = require('../../src/controllers/authController');
const twilioService = require('../../src/services/twilioService');
const db = require('../../src/database');
const jwt = require('jsonwebtoken');
const { mockRequest, mockResponse, mockNext, createTestUser } = require('../helpers/testHelpers');

// Mock dependencies
jest.mock('../../src/services/twilioService');
jest.mock('../../src/database');

describe('AuthController', () => {
  let req, res, next;

  beforeEach(() => {
    req = mockRequest();
    res = mockResponse();
    next = mockNext();
    jest.clearAllMocks();
  });

  describe('sendOTP', () => {
    it('should send OTP successfully', async () => {
      req.body = { phoneNumber: '+966500000001' };

      twilioService.sendOTP.mockResolvedValue({
        status: 'pending',
        to: '+966500000001'
      });

      await authController.sendOTP(req, res);

      expect(twilioService.sendOTP).toHaveBeenCalledWith('+966500000001');
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: 'OTP sent successfully'
      });
    });

    it('should return 400 if phone number is missing', async () => {
      req.body = {};

      await authController.sendOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Phone number is required'
      });
    });

    it('should return 400 if phone number is invalid', async () => {
      req.body = { phoneNumber: 'invalid' };

      await authController.sendOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Invalid phone number format'
      });
    });

    it('should handle Twilio errors', async () => {
      req.body = { phoneNumber: '+966500000001' };

      twilioService.sendOTP.mockRejectedValue(new Error('Twilio error'));

      await authController.sendOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Failed to send OTP'
      });
    });
  });

  describe('verifyOTP', () => {
    it('should verify OTP and login existing user', async () => {
      req.body = {
        phoneNumber: '+966500000001',
        code: '123456'
      };

      const testUser = createTestUser();

      twilioService.verifyOTP.mockResolvedValue({
        status: 'approved'
      });

      db.query
        .mockResolvedValueOnce({ rows: [testUser] }) // Find user
        .mockResolvedValueOnce({ rows: [testUser] }); // Update last login

      await authController.verifyOTP(req, res);

      expect(twilioService.verifyOTP).toHaveBeenCalledWith('+966500000001', '123456');
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Login successful',
          user: expect.objectContaining({
            id: testUser.id,
            phoneNumber: testUser.phone_number
          }),
          token: expect.any(String),
          refreshToken: expect.any(String)
        })
      );
    });

    it('should verify OTP and create new user', async () => {
      req.body = {
        phoneNumber: '+966500000001',
        code: '123456'
      };

      const newUser = createTestUser();

      twilioService.verifyOTP.mockResolvedValue({
        status: 'approved'
      });

      db.query
        .mockResolvedValueOnce({ rows: [] }) // No existing user
        .mockResolvedValueOnce({ rows: [newUser] }); // Create new user

      await authController.verifyOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          isNewUser: true
        })
      );
    });

    it('should return 400 if OTP is invalid', async () => {
      req.body = {
        phoneNumber: '+966500000001',
        code: '123456'
      };

      twilioService.verifyOTP.mockResolvedValue({
        status: 'pending'
      });

      await authController.verifyOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Invalid OTP code'
      });
    });

    it('should return 400 if required fields are missing', async () => {
      req.body = { phoneNumber: '+966500000001' };

      await authController.verifyOTP(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
    });
  });

  describe('refreshToken', () => {
    it('should refresh token successfully', async () => {
      const testUser = createTestUser();
      const refreshToken = jwt.sign(
        { userId: testUser.id, type: 'refresh' },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
      );

      req.body = { refreshToken };

      db.query.mockResolvedValue({ rows: [testUser] });

      await authController.refreshToken(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        token: expect.any(String),
        refreshToken: expect.any(String)
      });
    });

    it('should return 400 if refresh token is missing', async () => {
      req.body = {};

      await authController.refreshToken(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
    });

    it('should return 401 if refresh token is invalid', async () => {
      req.body = { refreshToken: 'invalid-token' };

      await authController.refreshToken(req, res);

      expect(res.status).toHaveBeenCalledWith(401);
    });
  });

  describe('logout', () => {
    it('should logout successfully', async () => {
      req.user = { userId: 'test-user-id' };

      await authController.logout(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: 'Logged out successfully'
      });
    });
  });

  describe('getCurrentUser', () => {
    it('should return current user', async () => {
      const testUser = createTestUser();
      req.user = { userId: testUser.id };

      db.query.mockResolvedValue({ rows: [testUser] });

      await authController.getCurrentUser(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        user: expect.objectContaining({
          id: testUser.id
        })
      });
    });

    it('should return 404 if user not found', async () => {
      req.user = { userId: 'non-existent' };

      db.query.mockResolvedValue({ rows: [] });

      await authController.getCurrentUser(req, res);

      expect(res.status).toHaveBeenCalledWith(404);
    });
  });
});
